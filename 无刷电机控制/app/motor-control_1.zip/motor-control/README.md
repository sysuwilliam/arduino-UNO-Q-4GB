# Brushless Motor Control

这是一个用于 Arduino UNO Q 的 App Lab 项目，用来通过 SimpleFOCmini 驱动板控制 1 个无刷电机。

当前程序运行在 UNO Q 的 MCU 侧 `sketch/sketch.ino` 中，使用 SimpleFOC 做闭环角度控制。Python 侧 `python/main.py` 负责启动 Web UI、接收网页调参命令，并通过 RouterBridge 调用 MCU 侧接口。实时 FOC 控制仍然只放在 MCU 侧。

## 当前任务

程序完成的任务：

- 通过 UNO Q 的 `D3`、`D5`、`D6` 输出三路 PWM 到 SimpleFOCmini 驱动板。
- 通过 UNO Q 的 `D8` 控制驱动板 `EN` 使能脚。
- 通过 I2C 读取 AS5600 磁编码器角度。
- 使用 SimpleFOC 的 `MotionControlType::angle` 做闭环位置控制。
- 通过串口命令或 Web UI 设置目标角度，角度单位为弧度。
- 通过 Web UI 实时修改关键参数并查看遥测波形。

## 接线

当前代码对应的接线如下：

| 模块 | 引脚 | 连接 |
|---|---|---|
| SimpleFOCmini | PWM1/PWM2/PWM3 | UNO Q `D3` / `D5` / `D6` |
| SimpleFOCmini | EN | UNO Q `D8` |
| SimpleFOCmini | VIN/GND | 电源板 `10V` / `GND` |
| SimpleFOCmini | VCC/GND | 电源板 `3V3` / `GND` |
| AS5600 编码器 | SDA/SCL | UNO Q `SDA` / `SCL` |
| AS5600 编码器 | VCC/GND | 电源板 `3V3` / `GND` |
| 无刷电机 | 三相线 | SimpleFOCmini 三相输出 |
| UNO Q | GND | 电源板 `GND` |

所有模块必须共地。

## 关键参数

当前代码中的关键参数：

```cpp
constexpr int PWM_U_PIN = 3;
constexpr int PWM_V_PIN = 5;
constexpr int PWM_W_PIN = 6;
constexpr int ENABLE_PIN = 8;

constexpr float POWER_SUPPLY_VOLTAGE = 10.0f;
constexpr float STARTUP_VOLTAGE_LIMIT = 1.5f;
constexpr float STARTUP_VELOCITY_LIMIT = 10.0f;
constexpr int MOTOR_POLE_PAIRS = 7;
```

首次测试时 `motor.voltage_limit` 被限制为 `1.5V`，这是为了降低电机抖动、发热或接线错误时的风险。确认电机运行稳定后，再逐步提高限压。

## 运行方式

1. 在 App Lab 中安装 sketch library：`Simple FOC`。
2. 确认 sketch library 中也包含 `Arduino_RouterBridge`；当前 `sketch/sketch.yaml` 已经写入依赖。
3. 确认电机供电、逻辑供电、编码器供电和共地接线正确。
4. 点击 App Lab 右上角 `Run`。
5. App Lab 会启动 Web UI，通常可以通过浏览器访问 `<board-name>.local:7000` 或板子的 IP 地址端口 `7000`。
6. 也可以打开 MCU 串口监视器，波特率设置为 `115200`，继续使用串口命令。

示例命令：

```text
T0
T1.57
T3.14
```

角度单位是弧度：

$$
1.57 \text{ rad} \approx 90^\circ
$$

$$
3.14 \text{ rad} \approx 180^\circ
$$

## Web UI 功能

Web UI 位于：

```text
assets/index.html
assets/app.js
assets/style.css
```

网页当前提供：

- 目标角度滑条和数字输入，单位支持 `rad` 和 `deg`。
- `Hold` 按钮：把当前电机角度设置为新的目标角度。
- `Zero` 按钮：目标角度设置为 `0 rad`。
- `Enable/Disable` 按钮：启用或禁用电机输出。
- `voltage_limit` 实时调节。
- `velocity_limit` 实时调节。
- `P_angle` 实时调节。
- 速度环 `P/I/D` 实时调节。
- 实时波形图：显示目标角度、当前角度和角度误差。
- 状态卡片：显示当前角度、目标角度、误差、速度、限压和电机使能状态。

网页与 MCU 的数据流：

```text
Web UI
  -> Socket.IO
  -> python/main.py
  -> RouterBridge
  -> sketch/sketch.ino
  -> SimpleFOC
```

MCU 侧保留高频实时控制：

```cpp
motor.loopFOC();
motor.move(target_angle);
```

Python 侧每 `50ms` 读取一次 MCU 遥测数据，并推送给 Web UI 画波形。

## 注意事项

- `10V` 电机供电只能接驱动板 `VIN`，不要接到 UNO Q 或编码器的 `VCC`。
- 第一次运行时建议电源限流，并让电机空载测试。
- 如果电机抖动、不转或发热，先停止运行，检查三相线顺序、编码器方向、磁铁安装位置和极对数。
- 如果编译提示找不到 `SimpleFOC.h`，说明没有安装 `Simple FOC` 库。
- 如果 Web UI 无法打开，确认 `app.yaml` 中存在 `arduino:web_ui` brick，并确认 App Lab 运行在支持网络访问的模式。
- 如果 Web UI 显示遥测失败，优先检查 MCU 是否成功编译运行、`Arduino_RouterBridge` 是否安装、以及 `sketch.ino` 是否打印 `Motor ready.`。

## 维护约定

以后每次修改 `sketch/sketch.ino`、接线方式、控制模式或关键参数时，都要同步更新这个 README。


