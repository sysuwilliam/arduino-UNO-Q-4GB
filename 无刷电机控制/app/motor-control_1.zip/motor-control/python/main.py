import time

from arduino.app_utils import App, Bridge
from arduino.app_bricks.web_ui import WebUI

ui = WebUI()

TELEMETRY_INTERVAL_SEC = 0.05
last_telemetry = None

print("Brushless motor control app started.")
print("The SimpleFOC control loop runs on the UNO Q MCU sketch.")
print("Open the Web UI to tune target angle, limits, and PID parameters.")


def parse_telemetry(raw):
    """Parse the CSV telemetry string returned by the MCU sketch."""
    fields = str(raw).split(",")
    if len(fields) != 12:
        raise ValueError(f"Expected 12 telemetry fields, got {len(fields)}: {raw}")

    return {
        "millis": int(float(fields[0])),
        "target_angle": float(fields[1]),
        "shaft_angle": float(fields[2]),
        "shaft_velocity": float(fields[3]),
        "angle_error": float(fields[4]),
        "voltage_limit": float(fields[5]),
        "velocity_limit": float(fields[6]),
        "angle_p": float(fields[7]),
        "velocity_p": float(fields[8]),
        "velocity_i": float(fields[9]),
        "velocity_d": float(fields[10]),
        "enabled": fields[11].strip() == "1",
    }


def call_mcu(method, *args):
    """Call an MCU RPC method and report the result to the Web UI."""
    try:
        ok = Bridge.call(method, *args)
    except Exception as exc:
        ui.send_message("status", message={"ok": False, "message": f"{method} failed: {exc}"})
        return False

    ui.send_message("status", message={"ok": bool(ok), "message": f"{method}: {'ok' if ok else 'failed'}"})
    return bool(ok)


def handle_set_target(_sid, value):
    call_mcu("set_target_angle", float(value))


def handle_set_voltage_limit(_sid, value):
    call_mcu("set_voltage_limit", float(value))


def handle_set_velocity_limit(_sid, value):
    call_mcu("set_velocity_limit", float(value))


def handle_set_angle_p(_sid, value):
    call_mcu("set_angle_p", float(value))


def handle_set_velocity_p(_sid, value):
    call_mcu("set_velocity_p", float(value))


def handle_set_velocity_i(_sid, value):
    call_mcu("set_velocity_i", float(value))


def handle_set_velocity_d(_sid, value):
    call_mcu("set_velocity_d", float(value))


def handle_hold(_sid, *_args):
    call_mcu("hold_current_angle")


def handle_set_enabled(_sid, value):
    call_mcu("set_motor_enabled", bool(value))


ui.on_message("set_target_angle", handle_set_target)
ui.on_message("set_voltage_limit", handle_set_voltage_limit)
ui.on_message("set_velocity_limit", handle_set_velocity_limit)
ui.on_message("set_angle_p", handle_set_angle_p)
ui.on_message("set_velocity_p", handle_set_velocity_p)
ui.on_message("set_velocity_i", handle_set_velocity_i)
ui.on_message("set_velocity_d", handle_set_velocity_d)
ui.on_message("hold_current_angle", handle_hold)
ui.on_message("set_motor_enabled", handle_set_enabled)


def loop():
    """Poll MCU telemetry and forward it to the Web UI."""
    global last_telemetry

    try:
        raw = Bridge.call("get_telemetry")
        telemetry = parse_telemetry(raw)
        last_telemetry = telemetry
        ui.send_message("telemetry", message=telemetry)
    except Exception as exc:
        ui.send_message("status", message={"ok": False, "message": f"telemetry failed: {exc}"})

    time.sleep(TELEMETRY_INTERVAL_SEC)


App.run(user_loop=loop)
